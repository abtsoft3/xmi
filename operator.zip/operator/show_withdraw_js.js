var gentable = null;
$(document).ready(function(){
	var id_wdw = $('#query_str').val();
	
	gentable=$('#tbl_deposit').DataTable({
		processing:true,
		responsive:true,
		ajax:'read_withdraw.php?id='+id_wdw+'',
		columns:[
		{data:'username'},
		{data:'amount_withdraw'},
		{data:'date_time_req_wdw'},
		
		{"className": "action text-center",
		"data": null,
		"bSortable": false,
		"defaultContent": "" +
		"<button class='confirm btn btn-success btn-xs' rel='tooltip' data-toggle='tooltip' data-placement='left' title='Confirm'><i class='fa fa-check'></i></button>"
         +"<div class='btn-group' role='group'>" +
          "<button class='edit  btn btn-primary btn-xs' rel='tooltip' data-toggle='tooltip' data-placement='top' title='Edit'><i class='fa fa-edit'></i></button>" +
          " <button class='delete btn btn-danger btn-xs' rel='tooltip' data-toggle='tooltip' data-placement='right' title='Hapus'><i class='fa fa-trash-o'></i></button>" +
          "</div>"
		}
		]
	});
	var sbody = $('#tbl_deposit tbody');
	sbody.on('click','.confirm',function()
	{
		$('#modal_confirm_withdraw').modal('show');
		
		
	});
	$('#btn-submit-withdraw').click(function(){
			//e.preventDefault();
			$.ajax({
				type:'POST',
				url:'save_confirm_withdraw.php',
				data:{'id_wdw':id_wdw},
				success:function(data){
					if(data>0)
					{
						gentable.ajax.reload();
					}
				},
				error:function(xhr,textStatus,errMsg)
				{
					console.log(errMsg + " "+ " "+xhr.status+textStatus);
				},
				complete:function()
				{
					$('#modal_confirm_withdraw').modal('hide');
				}
				
			});
			
		});
	$('body').tooltip({
			selector: '[rel=tooltip]'
		});
});